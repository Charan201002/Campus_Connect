<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Home - Campus Connect Hub</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <!-- <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon"> -->

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">
</head>

<body class="index-page">

  <header id="header" class="header sticky-top">

    <div class="topbar d-flex align-items-center dark-background">
      <div class="container d-flex justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center">
          <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:tempoxop@gmail.com">contact@campusconnect.com</a></i>
          <i class="bi bi-phone d-flex align-items-center ms-4"><span>+91 123 456 7890</span></i>
        </div>
        <div class="social-links d-none d-md-flex align-items-center">
          <a href="https://x.com/" target="_blank" class="twitter"><i class="bi bi-twitter-x"></i></a>
          <a href="https://www.facebook.com/" target="_blank" class="facebook"><i class="bi bi-facebook"></i></a>
          <a href="https://www.instagram.com/" target="_blank" class="instagram"><i class="bi bi-instagram"></i></a>
          <a href="https://in.linkedin.com/" target="_blank" class="linkedin"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>
    </div><!-- End Top Bar -->


    <!-- Marqueee events -->
    <div class="marquee-container">
      <div class="marquee-text">
          <div class="marquee-item">
              <i class="fas fa-laptop-code"></i>
              <span>Hackathon 2024 - December 5th</span>
          </div>
          <div class="marquee-item">
              <i class="fas fa-basketball-ball"></i>
              <span>Annual Sports Meet - December 12th</span>
          </div>
          <div class="marquee-item">
              <i class="fas fa-user-graduate"></i>
              <span>Alumni Reunion - December 22nd</span>
          </div>
          <div class="marquee-item">
              <i class="fas fa-theater-masks"></i>
              <span>Cultural Fest - January 15th</span>
          </div>
      </div>
  </div><!-- end marquee  -->

  
    <div class="branding">

      <div class="container position-relative d-flex align-items-center justify-content-between">
        <a href="index.html" class="logo d-flex align-items-center">
          <!-- For Logo -->
          <!-- <img src="assets/img/logo" alt=""> -->
          <h1 class="sitename">Campus Connect Hub<br></h1>
        </a>

        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index.html" class="active">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="courses.html">Courses</a></li>
            <li><a href="team.html">Team</a></li>
            <li><a href="gallery.php
            ">Gallery</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>

      </div>

    </div>

  </header>

  <main class="main">

    <!-- Hero Section -->
    <section id="hero" class="hero section">

      <div id="hero-carousel" class="carousel slide carousel-fade" data-bs-ride="carousel" data-bs-interval="5000">

        <div class="carousel-item active">
          <img src="assets/img/hero-carousel/home1.webp" alt="">
          <div class="carousel-container">
            <h2>Welcome to <span>Campus Connect Hub</span></h2>
            <p>With over 50 undergraduate, postgraduate, and doctoral programs, the college ensures a variety of academic options tailored to meet the demands of diverse industries.</p>
            <a href="courses.html" class="btn-get-started">Explore Courses</a>
          </div>
        </div><!-- End Carousel Item -->

        <div class="carousel-item">
          <img src="assets/img/hero-carousel/home2.jpg" alt="">
          <div class="carousel-container">
            <h2>World-Class Infrastructure</h2>
            <p>The college boasts state-of-the-art infrastructure, including modern classrooms, fully equipped laboratories, and a comprehensive library with digital resources.</p>
            <!-- <a href="about.html" class="btn-get-started">Get Started</a> -->
          </div>
        </div><!-- End Carousel Item -->

        <div class="carousel-item">
          <img src="assets/img/hero-carousel/home3.jpg" alt="">
          <div class="carousel-container">
            <h2>Vibrant Campus Life</h2>
            <p>The campus fosters an engaging and inclusive environment with various clubs, cultural activities, and sports facilities, creating a well-rounded student experience.</p>
            <!-- <a href="about.html" class="btn-get-started">Get Started</a> -->
          </div>
        </div><!-- End Carousel Item -->

        <a class="carousel-control-prev" href="#hero-carousel" role="button" data-bs-slide="prev">
          <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
        </a>

        <a class="carousel-control-next" href="#hero-carousel" role="button" data-bs-slide="next">
          <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
        </a>

      </div>

      <div class="featured container">

        <div class="row gy-4">

          <div class="col-lg-4 d-flex" data-aos="fade-up" data-aos-delay="100">
            <div class="featured-item position-relative">
              <div class="icon"><i class="bi bi-mortarboard icon"></i></div>
              <h4><a href="" class="stretched-link">World-Class Education</a></h4>
              <p>We offer top-notch courses taught by industry experts.</p>
            </div>
          </div><!-- End Featured Item -->

          <div class="col-lg-4 d-flex" data-aos="fade-up" data-aos-delay="200">
            <div class="featured-item position-relative">
              <div class="icon"><i class="bi bi-book icon"></i></div>
              <h4><a href="" class="stretched-link">Expert Faculty</a></h4>
              <p>Learn from highly qualified and experienced educators.</p>
            </div>
          </div><!-- End Featured Item -->

          <div class="col-lg-4 d-flex" data-aos="fade-up" data-aos-delay="300">
            <div class="featured-item position-relative">
              <div class="icon"><i class="bi bi-patch-check icon"></i></div>
              <h4><a href="" class="stretched-link">Recognized Degrees</a></h4>
              <p>Get globally recognized certifications and degrees.</p>
            </div>
          </div><!-- End Featured Item -->

        </div>

      </div>

    </section><!-- /Hero Section -->

    <!-- About Section -->
    <section id="about" class="section about">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">
          <div class="col-lg-6 order-1 order-lg-2">
            <img src="assets/img/about.jpg" class="img-fluid" alt="">
          </div>
          <div class="col-lg-6 order-2 order-lg-1 content">
            <h3>Welcome to Campus Connect Hub</h3>
            <p class="fst-italic">
              Campus Connect Hub is your gateway to a thriving educational ecosystem. Designed to bridge the gap between students, faculty, and institutions, our platform creates an engaging environment for learning, collaboration, and personal growth.
            </p>
            <ul>
              <li><i class="bi bi-check2-all"></i> <span>Seamless Communication: Stay updated with announcements, events, and academic schedules.</span></li>
              <li><i class="bi bi-check2-all"></i> <span>Resource Access: Explore an extensive library of e-books, research papers, and learning materials.</span></li>
              <li><i class="bi bi-check2-all"></i> <span>Community Engagement: Join clubs, participate in events, and network with peers and professionals.</span></li>
            </ul>
            <p>
              <h3>Why Choose Us?</h3>
              At Campus Connect Hub, we believe in empowering students to achieve their dreams. Our mission is to provide a robust platform that fosters excellence in academics and beyond.
              
              <br>Stay connected, stay informed, and unlock endless possibilities with Campus Connect Hub!
            </p>
          </div>
        </div>

      </div>

    </section><!-- /About Section -->

    <!-- Stats Section -->
    <section id="stats" class="stats section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">

          <div class="col-lg-3 col-md-6">
            <div class="stats-item">
              <!-- <i class="bi bi-emoji-smile"></i> -->
              <i class="fas fa-user-graduate" style="margin-top:25px ;padding-right: 25px;"></i>
              <span data-purecounter-start="0" data-purecounter-end="20156" data-purecounter-duration="1" class="purecounter"></span>
              <p><strong>Students Enrolled</strong> <!--<span>consequuntur quae</span>--></p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item">
              <i class="fas fa-chalkboard-teacher " style="margin-top:25px ;padding-right: 25px;"></i>
              <!-- <i class="bi bi-journal-richtext"></i>               -->
              <span data-purecounter-start="0" data-purecounter-end="721" data-purecounter-duration="1" class="purecounter"></span>
              <p><strong>Certified Teachers</strong> <!--<span>adipisci atque cum quia aut</span>--></p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item">
              <!-- <i class="bi bi-headset"></i> -->
              <i class="fas fa-university" style="margin-top:25px ;padding-right: 25px;"></i>
              <span data-purecounter-start="0" data-purecounter-end="19973" data-purecounter-duration="1" class="purecounter"></span>
              <p><strong>Passing to Universities</strong> <!--<span>aut commodi quaerat</span>--></p>
            </div>
          </div><!-- End Stats Item -->

          <div class="col-lg-3 col-md-6">
            <div class="stats-item">
              <i class="bi bi-people" style="margin-top:10px ;padding-right: 25px;"></i>
              <span data-purecounter-start="0" data-purecounter-end="100" data-purecounter-duration="1" class="purecounter"></span>
              <p><strong>Parents Satisfaction</strong> <!--<span>rerum asperiores dolor</span>--></p>
            </div>
          </div><!-- End Stats Item -->

        </div>

      </div>

    </section><!-- /Stats Section -->


    <!-- Company Section -->
    <section id="clients" class="section clients">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
        <h2>Campus Selection Companies</h2>
        <p>Our college takes pride in its exceptional campus recruitment process, connecting students with leading companies from various industries. With a focus on skill development and career readiness, we achieve impressive placement rates annually. The dedicated training programs ensure students are well-prepared to excel in interviews and secure their dream jobs.</p>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="swiper init-swiper">
          <script type="application/json" class="swiper-config">
            {
              "loop": true,
              "speed": 600,
              "autoplay": {
                "delay": 5000
              },
              "slidesPerView": "auto",
              "pagination": {
                "el": ".swiper-pagination",
                "type": "bullets",
                "clickable": true
              },
              "breakpoints": {
                "320": {
                  "slidesPerView": 2,
                  "spaceBetween": 40
                },
                "480": {
                  "slidesPerView": 3,
                  "spaceBetween": 60
                },
                "640": {
                  "slidesPerView": 4,
                  "spaceBetween": 80
                },
                "992": {
                  "slidesPerView": 6,
                  "spaceBetween": 120
                }
              }
            }
          </script>
          <div class="swiper-wrapper align-items-center">
            <div class="swiper-slide"><img src="assets/img/clients/1.jpg" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/2.jpeg" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/3.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/4.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/5.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/6.png" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/7.jpg" class="img-fluid" alt=""></div>
            <div class="swiper-slide"><img src="assets/img/clients/8.jpg" class="img-fluid" alt=""></div>
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>

    </section><!-- /company Section -->

  </main>

  <footer id="footer" class="footer position-relative dark-background">

    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6 footer-about">
          <a href="index.html" class="d-flex align-items-center">
            <span class="sitename">Campus Connect Hub</span>
          </a>
          <div class="footer-contact pt-3">
            <p>Silk Institute</p>
            <p>Bengaluru, KA 560082</p>
            <p class="mt-3"><strong>Phone:</strong> <span>+91 1234 567 890</span></p>
            <p><strong>Email:</strong> <span>contact@campusconnect.com</span></p>
          </div>
        </div>

        <div class="col-lg-2 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><i class="bi bi-chevron-right"></i> <a href="index.html">Home</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="about.html">About us</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="courses.html">Courses</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="contact.html">Contact</a></li>
          </ul>
        </div>

        <div class="col-lg-4 col-md-12">
          <h4>Follow Us</h4>
          <!-- <p>Cras fermentum odio eu feugiat lide par naso tierra videa magna derita valies</p> -->
          <div class="social-links d-flex">
            <a href="https://x.com/" target="_blank"><i class="bi bi-twitter-x"></i></a>
            <a href="https://www.facebook.com/" target="_blank"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/" target="_blank"><i class="bi bi-instagram"></i></a>
            <a href="https://in.linkedin.com/" target="_blank"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

      </div>
    </div>

    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Campus Connect Hub</strong> <span>All Rights
          Reserved</span></p>
      <div class="credits">
        Designed by CHARAN</a>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script> 
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>