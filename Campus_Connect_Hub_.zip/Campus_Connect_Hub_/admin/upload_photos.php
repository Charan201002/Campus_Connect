<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $photoType = $_POST['photo_type'];
    $uploadedFiles = $_FILES['photos'];

    // Database connection
    $conn = new mysqli("localhost", "root", "", "campus_connect");

    if ($conn->connect_error) {
        die("Database connection failed: " . $conn->connect_error);
    }

    for ($i = 0; $i < count($uploadedFiles['name']); $i++) {
        $fileName = basename($uploadedFiles['name'][$i]);
        $fileTmpName = $uploadedFiles['tmp_name'][$i];

        // Read image data
        $imageData = file_get_contents($fileTmpName);

        // Insert image into the database
        $stmt = $conn->prepare("INSERT INTO images (image, type, image_data) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $fileName, $photoType, $imageData);
        $stmt->execute();
    }

    $conn->close();
    header("Location: ../gallery.php");
    exit;
}
?>
