<?php
// Database connection
$servername = "localhost"; // Your database server
$username = "root";        // Your database username
$password = "";            // Your database password
$dbname = "campus_connect"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $event_name = $_POST['event_name'];
    $event_date = $_POST['event_date'];
    $event_description = $_POST['event_description'];
    
    // Handle file upload
    if (isset($_FILES['event_image']) && $_FILES['event_image']['error'] == 0) {
        $image = $_FILES['event_image'];
        $image_name = $image['name']; // Use the original file name
        $image_tmp = $image['tmp_name'];
        $image_size = $image['size'];
        
        // Define the upload directory
        $upload_dir = "assets/img/";
        $upload_path = $upload_dir . $image_name;

        // Check the file type and size (optional)
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if (in_array($image['type'], $allowed_types) && $image_size < 5000000) {
            // Check if the file already exists
            if (file_exists($upload_path)) {
                // Generate a unique name by appending a timestamp to the original file name
                $image_name = time() . "_" . $image_name;
                $upload_path = $upload_dir . $image_name;
            }
            
            // Move the uploaded file to the server
            if (move_uploaded_file($image_tmp, $upload_path)) {
                // Prepare the SQL query
                $sql = "INSERT INTO events (event_name, event_date, event_description, event_image) 
                        VALUES ('$event_name', '$event_date', '$event_description', '$image_name')";

                if ($conn->query($sql) === TRUE) {
                    echo "New event added successfully.";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            } else {
                echo "Error uploading image.";
            }
        } else {
            echo "Invalid file type or file size too large.";
        }
    } else {
        echo "Please upload an image.";
    }
}

$conn->close();
?>
