<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Database connection
    $conn = new mysqli('localhost', 'root', '', 'campus_connect');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Collect data
    $username = $conn->real_escape_string($_POST['username']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $email = $conn->real_escape_string($_POST['email']);

    // Insert into database
    $sql = "INSERT INTO admin_users (username, password, email) VALUES ('$username', '$password', '$email')";

    if ($conn->query($sql) === TRUE) {
        echo "Signup successful! <a href='index.php'>Login here</a>.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Signup</title>
    <style>
        /* General Styles */
body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 20px;
}

.container {
    max-width: 500px;
    margin: 0 auto;
    background-color: #fff;
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    color: #E238EC;
    margin-bottom: 20px;
}

/* Form Styles */
.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
    color: #333;
}

input[type="text"], input[type="password"], input[type="email"] {
    width: 100%;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
    box-sizing: border-box;
}

input[type="text"]:focus, input[type="password"]:focus, input[type="email"]:focus {
    border-color: #E238EC;
    outline: none;
}

/* Submit Button */
button[type="submit"] {
    width: 100%;
    padding: 12px;
    background-color: #E238EC;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button[type="submit"]:hover {
    background-color: #D41FDC;
}

/* Switch Section */
.switch {
    text-align: center;
    margin-top: 20px;
    font-size: 14px;
}

.switch a {
    color: #E238EC;
    text-decoration: none;
}

.switch a:hover {
    text-decoration: underline;
}

/* Responsive Styles */
@media (max-width: 768px) {
    .container {
        padding: 20px;
    }

    h2 {
        font-size: 24px;
    }

    button[type="submit"] {
        font-size: 14px;
    }
}

    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Signup</h2>
        <form action="signup.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <button type="submit" class="btn">Sign Up</button>
        </form>
        <div class="switch">
            Already have an account? <a href="index.php">Login here</a>.
        </div>
    </div>
</body>
</html>
<?php } ?>
