<?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "campus_connect");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle image deletion
if (isset($_GET['delete_id'])) {
    $deleteId = $_GET['delete_id'];

    // Delete the record from the database
    $conn->query("DELETE FROM images WHERE id = $deleteId");
    echo "<script>alert('Image deleted successfully');</script>";

    // Redirect to refresh the page
    header("Location: view_images.php");
    exit;
}

// Fetch all images
$result = $conn->query("SELECT id, type, image_data FROM images");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Images</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet"> Font Awesome -->
    <link rel="stylesheet" href="assets/css/navbar.css">
    <link rel="stylesheet" href="assets/css/styles1.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container">
    <a class="navbar-brand" href="dashboard.php">Admin Dashboard</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link" href="add_event.html">Add Event</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_events.php">View Events</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_photos.html">Add Photos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_images.php">View Images</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <button class="btn-logout">Logout</button>
                </a>
            </li>
        </ul>
    </div>
    </div>
</nav>

<div class="container">
    <br>
    <h2 class="text-center" >Manage Images</h2>
    <div class="table-container">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td>
                                <!-- Dynamically serve the image -->
                                <img src="data:image/jpeg;base64,<?= base64_encode($row['image_data']) ?>" 
                                     alt="Image" 
                                     class="event-image">
                            </td>
                            <td><?= ucfirst($row['type']) ?></td>
                            <td>
                                <a href="?delete_id=<?= $row['id'] ?>" 
                                   class="btn btn-danger"
                                   onclick="return confirm('Are you sure you want to delete this image?')">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4">No images found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>
