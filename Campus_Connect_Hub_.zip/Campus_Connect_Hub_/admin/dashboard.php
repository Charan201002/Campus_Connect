<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet"> <!-- Font Awesome -->
    <link rel="stylesheet" href="assets/css/navbar.css">
    <link rel="stylesheet" href="assets/css/styles1.css">

</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container">
    <a class="navbar-brand" href="dashboard.php">Admin Dashboard</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item">
                <a class="nav-link" href="add_event.html">Add Event</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_events.php">View Events</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="add_photos.html">Add Photos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="view_images.php">View Images</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <button class="btn-logout">Logout</button>
                </a>
            </li>
        </ul>
    </div>
    </div>
</nav>

    <!-- Main Content -->
    <div class="container">
    <div class="container mt-5">
    <h2 class="Hmm" > Hello, 
        <span class="Mmm" >
        <i class="fa-regular fa-user ok"></i> <!-- User icon -->
            <?php echo $_SESSION['admin']; ?>
        </span>
    </h2>
</div>
        <br>
        <div class="container mt-5">
    <div class="row">
        <div class="col-sm-6 mb-3 mb-sm-0">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title Hmm"><span class="Mmm" ><i class="fa-regular fa-envelope ok"></i> <!-- User icon -->   
                        </span> View Contact Messages</h3>          
                    <p class="card-text">Click to view messages from users who have contacted you.</p>
                    <a href="admin_contact_view.php" class="btn btn-primary">View Messages</a>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <div class="card">
                <div class="card-body">
                <h3 class="card-title Hmm"><span class="Mmm"><i class="fa-regular fa-calendar-check ok"></i> <!-- User icon -->   
                </span>View Event Registration Messages</h3>
                    <p class="card-text">Click to view messages from users who have registered for events.</p>
                    <a href="admin_view.php" class="btn btn-primary">View Messages</a>
                </div>
            </div>
        </div>
    </div>
</div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</body>
</html>
