<?php
// Database connection
$servername = "localhost"; // Your database server
$username = "root";        // Your database username
$password = "";            // Your database password
$dbname = "campus_connect"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch events from the database
$sql = "SELECT * FROM events";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Events - </title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <!-- <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon"> -->

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">

  <style>
    .hhnbv {
      display: block;
      font-size: 15px;
      padding-bottom: 10px;
      position: relative;
      font-weight: 500;
      color: #444444;
    }

    .vjkhj {
      display: block;
      margin-block-start: 1em;
      margin-block-end: 1em;
      margin-inline-start: 0px;
      margin-inline-end: 0px;
      unicode-bidi: isolate;
      color: #444444;
    }

    .event-card {
      background: #ffffff;
      /* box-shadow: 0 8px 20px rgba(226, 56, 236, 0.3); */
      border-radius: 10px;
      overflow: hidden;
      /* max-width: 350px; */
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .event-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 12px 30px rgba(226, 56, 236, 0.5);
    }

    /* Button Style */
    .boton {
      display: inline-block;
      padding: 12px 24px;
      background-color: #E238EC;
      /* Purple color */
      color: white;
      text-align: center;
      text-decoration: none;
      font-size: 1rem;
      border-radius: 6px;
      transition: background-color 0.3s ease, transform 0.3s ease;
    }

    .boton:hover {
      background-color: #E238EC;
      /* Darker shade of purple on hover */
      transform: scale(1.05);
      /* Slight zoom effect */
      color: white;
    }
  </style>

</head>

<body class="blog-page">
  <header id="header" class="header sticky-top">
    <div class="topbar d-flex align-items-center dark-background">
      <div class="container d-flex justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center">
          <i class="bi bi-envelope d-flex align-items-center"><a
              href="mailto:tempoxop@gmail.com">contact@campusconnect.com</a></i>
          <i class="bi bi-phone d-flex align-items-center ms-4"><span>+91 123 456 7890</span></i>
        </div>
        <div class="social-links d-none d-md-flex align-items-center">
          <a href="https://x.com/" target="_blank" class="twitter"><i class="bi bi-twitter-x"></i></a>
          <a href="https://www.facebook.com/" target="_blank" class="facebook"><i class="bi bi-facebook"></i></a>
          <a href="https://www.instagram.com/" target="_blank" class="instagram"><i class="bi bi-instagram"></i></a>
          <a href="https://in.linkedin.com/" target="_blank" class="linkedin"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>
    </div><!-- End Top Bar -->

    <!-- Marqueee events -->
    <div class="marquee-container">
      <div class="marquee-text">
        <div class="marquee-item">
          <i class="fas fa-laptop-code"></i>
          <span>Hackathon 2024 - December 5th</span>
        </div>
        <div class="marquee-item">
          <i class="fas fa-basketball-ball"></i>
          <span>Annual Sports Meet - December 12th</span>
        </div>
        <div class="marquee-item">
          <i class="fas fa-user-graduate"></i>
          <span>Alumni Reunion - December 22nd</span>
        </div>
        <div class="marquee-item">
          <i class="fas fa-theater-masks"></i>
          <span>Cultural Fest - January 15th</span>
        </div>
      </div>
    </div><!-- end marquee  -->

    <div class="branding">

      <div class="container position-relative d-flex align-items-center justify-content-between">
        <a href="index.html" class="logo d-flex align-items-center">
          <!-- For Logo -->
          <!-- <img src="assets/img/logo" alt=""> -->
          <h1 class="sitename">Campus Connect Hub<br></h1>
        </a>
        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="courses.html">Courses</a></li>
            <li><a href="team.html">Team</a></li>
            <li><a href="gallery.php">Gallery</a></li>
            <li><a href="events.php" class="active">Events</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
      </div>
    </div>
  </header>

  <main class="main">
    <!-- Page Title -->
    <div class="page-title" data-aos="fade">
      <div class="container">
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">Events</li>
          </ol>
        </nav>
        <h1>Events</h1>
      </div>
    </div><!-- End Page Title -->
    <div class="container">
      <a href="event_registration.html" class="boton">Register Now</a>
    </div>

    <!-- Eventss -->
    <div class="container mb-4 mt-4">
      <div class="row gy-4">

      <?php
if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        // Fetch and sanitize event details
        $event_name = htmlspecialchars($row["event_name"]);
        $event_date = htmlspecialchars($row["event_date"]);
        $event_description = htmlspecialchars($row["event_description"]);
        $event_image = htmlspecialchars($row["event_image"]); // Assuming event_image is a filename stored in the database

        // Verify if the image file exists
        $image_path = "admin/assets/img/" . $event_image; // The directory where images are stored
        $image_src = file_exists($image_path) ? $image_path : "assets/img/default.jpg"; // Fallback to default image

        // Optional: You can add a check to prevent a missing image in the database itself.
        if (empty($event_image)) {
            $image_src = "../assets/img/default.jpg"; // Fallback if no image is set in the database
        }
?>
        <div class="col-lg-4 col-md-6 col-sm-12" data-aos="fade-up" data-aos-delay="100">
            <div class="card event-card">
                <div class="card-body shadow">
                    <!-- Display the event image -->
                    <img src="<?php echo $image_src; ?>" 
                         alt="<?php echo $event_name; ?> Image" 
                         style="width: 100px; height: 100px; border-radius: 10px; float: left; margin-right: 15px; object-fit: cover;">
                    <!-- Event details -->
                    <h5 class="card-title"><?php echo $event_name; ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo date("d-m-Y", strtotime($event_date)); ?></h6>
                    <p class="card-text"><?php echo $event_description; ?></p>
                </div>
            </div>
        </div>
<?php
    }
} else {
    echo "<p>No events available.</p>";
}
?>

        <div class="col-lg-4 col-md-6 col-sm-12" data-aos="fade-up" data-aos-delay="100">
          <div class="card event-card">
            <div class="card-body shadow">
              <img src="assets/img/event.jpg" alt="Event Image"
                style="width: 100px; height: 100px; border-radius: 10px; float: left; margin-right: 15px; object-fit: cover;">
              <h5 class="card-title">Hackathon 2024</h5>
              <h6 class="card-subtitle mb-2 text-muted">07-12-2024</h6>
              <p class="card-text">A 24-hour coding marathon for students to showcase their skills and win exciting
                prizes.</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12" data-aos="fade-up" data-aos-delay="200">
          <div class="card event-card">
            <div class="card-body shadow">
              <img src="assets/img/event.jpg" alt="Event Image"
                style="width: 100px; height: 100px; border-radius: 10px; float: left; margin-right: 15px; object-fit: cover;">
              <h5 class="card-title">Annual Sports Meet</h5>
              <h6 class="card-subtitle mb-2 text-muted">13-12-2024</h6>
              <p>A week-long celebration of athleticism, teamwork, and school spirit.</p>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6 col-sm-12" data-aos="fade-up" data-aos-delay="300">
          <div class="card event-card">
            <div class="card-body shadow">
              <img src="assets/img/event.jpg" alt="Event Image"
                style="width: 100px; height: 100px; border-radius: 10px; float: left; margin-right: 15px; object-fit: cover;">
              <h5 class="card-title">Alumni Reunion</h5>
              <h6 class="card-subtitle mb-2 text-muted">22-12-2024</h6>
              <p class="card-text">An evening to reconnect and network with our esteemed alumni community.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </main>

  <footer id="footer" class="footer position-relative dark-background">

    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6 footer-about">
          <a href="index.html" class="d-flex align-items-center">
            <span class="sitename">Campus Connect Hub</span>
          </a>
          <div class="footer-contact pt-3">
            <p>Silk Institute</p>
            <p>Bengaluru, KA 560082</p>
            <p class="mt-3"><strong>Phone:</strong> <span>+91 1234 567 890</span></p>
            <p><strong>Email:</strong> <span>contact@campusconnect.com</span></p>
          </div>
        </div>

        <div class="col-lg-2 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><i class="bi bi-chevron-right"></i> <a href="index.html">Home</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="about.html">About us</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="courses.html">Courses</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="contact.html">Contact</a></li>
          </ul>
        </div>

        <div class="col-lg-4 col-md-12">
          <h4>Follow Us</h4>
          <!-- <p>Cras fermentum odio eu feugiat lide par naso tierra videa magna derita valies</p> -->
          <div class="social-links d-flex">
            <a href="https://x.com/" target="_blank"><i class="bi bi-twitter-x"></i></a>
            <a href="https://www.facebook.com/" target="_blank"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/" target="_blank"><i class="bi bi-instagram"></i></a>
            <a href="https://in.linkedin.com/" target="_blank"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>
      </div>
    </div>

    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Campus Connect Hub</strong> <span>All Rights
          Reserved</span></p>
      <div class="credits">
        Designed by CHARAN</a>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>
</html>