<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Gallery - </title>
  <meta name="description" content="">
  <meta name="keywords" content="">
  <!-- Favicons -->
  <!-- <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon"> -->

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>

<body class="portfolio-page">

  <header id="header" class="header sticky-top">

    <div class="topbar d-flex align-items-center dark-background">
      <div class="container d-flex justify-content-center justify-content-md-between">
        <div class="contact-info d-flex align-items-center">
          <i class="bi bi-envelope d-flex align-items-center"><a href="mailto:tempoxop@gmail.com">contact@campusconnect.com</a></i>
          <i class="bi bi-phone d-flex align-items-center ms-4"><span>+91 123 456 7890</span></i>
        </div>
        <div class="social-links d-none d-md-flex align-items-center">
          <a href="https://x.com/" target="_blank" class="twitter"><i class="bi bi-twitter-x"></i></a>
          <a href="https://www.facebook.com/" target="_blank" class="facebook"><i class="bi bi-facebook"></i></a>
          <a href="https://www.instagram.com/" target="_blank" class="instagram"><i class="bi bi-instagram"></i></a>
          <a href="https://in.linkedin.com/" target="_blank" class="linkedin"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>
    </div><!-- End Top Bar -->

    <div class="branding">

      <div class="container position-relative d-flex align-items-center justify-content-between">
        <a href="index.html" class="logo d-flex align-items-center">
          <!-- For Logo -->
          <!-- <img src="assets/img/logo" alt=""> -->
          <h1 class="sitename">Campus Connect Hub<br></h1>
        </a>

        <nav id="navmenu" class="navmenu">
          <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="courses.html">Courses</a></li>
            <li><a href="team.html">Team</a></li>
            <li><a href="gallery.php" class="active">Gallery</a></li>
            <li><a href="events.php">Events</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
          <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
        </nav>
      </div>
    </div>
  </header>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title" data-aos="fade">
      <div class="container">
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.html">Home</a></li>
            <li class="current">Gallery</li>
          </ol>
        </nav>
        <h1>Gallery</h1>
      </div>
    </div><!-- End Page Title -->

    <!-- Portfolio Section -->

    <?php
// Database connection
$conn = new mysqli("localhost", "root", "", "campus_connect");
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Fetch images from the database
$sql = "SELECT image, type, image_data FROM images";
$result = $conn->query($sql);
$images = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $images[] = $row;
    }
}
$conn->close();
?>
    <section id="portfolio" class="portfolio section">

      <div class="container">

        <div class="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">

          <ul class="portfolio-filters isotope-filters" data-aos="fade-up" data-aos-delay="100">
            <li data-filter="*" class="filter-active">All</li>
            <li data-filter=".filter-app">College Infrastructure</li>
            <li data-filter=".filter-product">Event Photos</li>
            <!-- <li data-filter=".filter-branding">Branding</li>
            <li data-filter=".filter-books">Books</li> -->
          </ul><!-- End Portfolio Filters -->

          <div class="row gy-4 isotope-container" data-aos="fade-up" data-aos-delay="100">

          <div class="row gy-4 isotope-container" data-aos="fade-up" data-aos-delay="200">
    <?php foreach ($images as $image): ?>
        <div class="col-lg-4 col-md-6 portfolio-item isotope-item 
            <?= ($image['type'] === 'infrastructure') ? 'filter-app' : 'filter-product'; ?>">
            <div class="portfolio-content h-100">
                <!-- Convert binary data to base64 to display the image -->
                <img src="data:image/jpeg;base64,<?= base64_encode($image['image_data']); ?>" 
                     class="img-fluid" 
                     alt="<?= basename($image['image']); ?>" 
                     style="width: 100%;">
                <div class="portfolio-info">
                    <h4><?= basename($image['image']); ?></h4>
                    <a href="data:image/jpeg;base64,<?= base64_encode($image['image_data']); ?>" 
   title="<?= basename($image['image']); ?>" 
   data-gallery="portfolio-gallery-<?= $image['type']; ?>" 
   class="glightbox preview-link">
    <i class="bi bi-zoom-in"></i>
</a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-app">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/i1.jpg" class="img-fluid" alt="" style="width: 100%;">
                <div class="portfolio-info">
                  <h4>i1</h4>
                  <!-- <p>Lorem ipsum, dolor sit amet consectetur</p> -->
                  <a href="assets/img/portfolio/i1.jpg" title="" data-gallery="portfolio-gallery-app" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                  <!-- <a href="portfolio-details.html" title="More Details" class="details-link"><i class="bi bi-link-45deg"></i></a> -->
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-product">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/e1.jpg" class="img-fluid" alt="" style="width: 100%;">
                <div class="portfolio-info">
                  <h4>e1</h4>
                  <!-- <p>Lorem ipsum, dolor sit amet consectetur</p> -->
                  <a href="assets/img/portfolio/e1-1.jpg" title="" data-gallery="portfolio-gallery-product" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                  <!-- <a href="portfolio-details.html" title="More Details" class="details-link"><i class="bi bi-link-45deg"></i></a> -->
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-app">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/i2.jpg" class="img-fluid" alt=""style="width: 100%;">
                <div class="portfolio-info">
                  <h4>i2</h4>
                  <a href="assets/img/portfolio/i2.jpg" title="" data-gallery="portfolio-gallery-app" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-product">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/e2.jpg" class="img-fluid" alt="" style="width: 100%;">
                <div class="portfolio-info">
                  <h4>e2</h4>
                  <a href="assets/img/portfolio/e2.jpg" title="" data-gallery="portfolio-gallery-product" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-app">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/i3.jpg" class="img-fluid" alt="" style="width: 100%;">
                <div class="portfolio-info">
                  <h4>i3</h4>
                  <a href="assets/img/portfolio/i3.jpg" title="" data-gallery="portfolio-gallery-app" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-product">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/e3.jpg" class="img-fluid" alt="" style="width: 100%;">
                <div class="portfolio-info">
                  <h4>e3</h4>
                  <a href="assets/img/portfolio/e3.jpg" title="" data-gallery="portfolio-gallery-product" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-app">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/i4.jpg" class="img-fluid" alt="" style="width: 100%;">
                <div class="portfolio-info">
                  <h4>i4</h4>
                  <a href="assets/img/portfolio/i4.jpg" title="" data-gallery="portfolio-gallery-app" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-product">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/e4.jpeg" class="img-fluid" alt="" style="width: 100%;">
                <div class="portfolio-info">
                  <h4>e4</h4>
                  <a href="assets/img/portfolio/e4.jpeg" title="" data-gallery="portfolio-gallery-product" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-app">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/i5.jpg" class="img-fluid" alt="" style="width: 100%;">
                <div class="portfolio-info">
                  <h4>i5</h4>
                  <a href="assets/img/portfolio/i5.jpg" title="" data-gallery="portfolio-gallery-app" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

            <div class="col-lg-4 col-md-6 portfolio-item isotope-item filter-product">
              <div class="portfolio-content h-100">
                <img src="assets/img/portfolio/e5.jpg" class="img-fluid" alt="" style="width: 100%;">
                <div class="portfolio-info">
                  <h4>e5</h4>
                  <a href="assets/img/portfolio/e5.jpg" title="" data-gallery="portfolio-gallery-product" class="glightbox preview-link"><i class="bi bi-zoom-in"></i></a>
                </div>
              </div>
            </div><!-- End Portfolio Item -->

          </div><!-- End Portfolio Container -->
        </div>
      </div>
    </section><!-- /Portfolio Section -->
  </main>

  <footer id="footer" class="footer position-relative dark-background">

    <div class="container footer-top">
      <div class="row gy-4">
        <div class="col-lg-4 col-md-6 footer-about">
          <a href="index.html" class="d-flex align-items-center">
            <span class="sitename">Campus Connect Hub</span>
          </a>
          <div class="footer-contact pt-3">
            <p>Silk Institute</p>
            <p>Bengaluru, KA 560082</p>
            <p class="mt-3"><strong>Phone:</strong> <span>+91 1234 567 890</span></p>
            <p><strong>Email:</strong> <span>contact@campusconnect.com</span></p>
          </div>
        </div>

        <div class="col-lg-2 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><i class="bi bi-chevron-right"></i> <a href="index.html">Home</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="about.html">About us</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="courses.html">Courses</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="contact.html">Contact</a></li>
          </ul>
        </div>

        <div class="col-lg-4 col-md-12">
          <h4>Follow Us</h4>
          <!-- <p>Cras fermentum odio eu feugiat lide par naso tierra videa magna derita valies</p> -->
          <div class="social-links d-flex">
            <a href="https://x.com/" target="_blank"><i class="bi bi-twitter-x"></i></a>
            <a href="https://www.facebook.com/" target="_blank"><i class="bi bi-facebook"></i></a>
            <a href="https://www.instagram.com/" target="_blank"><i class="bi bi-instagram"></i></a>
            <a href="https://in.linkedin.com/" target="_blank"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>

      </div>
    </div>

    <div class="container copyright text-center mt-4">
      <p>© <span>Copyright</span> <strong class="px-1 sitename">Campus Connect Hub</strong> <span>All Rights
          Reserved</span></p>
      <div class="credits">
        Designed by CHARAN</a>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Your HTML and PHP Code for Images -->

<!-- Vendor JS Files -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>

<!-- GLightbox JS -->
<script src="https://cdn.jsdelivr.net/npm/glightbox@3.0.1/dist/js/glightbox.min.js"></script>

<!-- Main JS File -->
<script src="assets/js/main.js"></script>

<!-- Initialize GLightbox after DOM is ready -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const lightbox = GLightbox({
            selector: '.glightbox', // This targets the gallery images
            touchNavigation: true,  // Enable swipe navigation for mobile
            loop: true,            // Enable looping through images
            openEffect: 'fade',    // Animation when opening the lightbox
            closeEffect: 'fade'    // Animation when closing the lightbox
        });
    });
</script>

</body>
</html>